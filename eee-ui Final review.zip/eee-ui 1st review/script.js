
const canvas = document.getElementById("bgCanvas");
const ctx = canvas.getContext("2d");

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

let particles = [];
let pulseSpeed = 0.2; 


function syncWithBeat() {
 
  pulseSpeed = Math.sin(Date.now() * 0.005) * 0.5 + 1.5; 
}


for (let i = 0; i < 300; i++) {
  let color = Math.random() > 0.5 ? "rgba(0, 255, 255, " : "rgba(255, 0, 255, ";  articles
  particles.push({
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    radius: Math.random() * 2 + 1,  
    dx: (Math.random() - 0.5) * 2,  
    dy: (Math.random() - 0.5) * 2,
    color: color + (Math.random() * 0.5 + 0.4) + ")", 
    speed: Math.random() * 0.6 + 0.5  h
  });
}

function drawParticles() {
  ctx.clearRect(0, 0, canvas.width, canvas.height); 

  syncWithBeat(); 

  particles.forEach(p => {
    ctx.beginPath();
    ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
    ctx.fillStyle = p.color;
    ctx.fill();

    
    p.x += p.dx * p.speed * pulseSpeed;  
    p.y += p.dy * p.speed * pulseSpeed;

    if (p.x < 0) p.x = canvas.width;
    if (p.y < 0) p.y = canvas.height;
    if (p.x > canvas.width) p.x = 0;
    if (p.y > canvas.height) p.y = 0;
  });

  requestAnimationFrame(drawParticles);
}

drawParticles();


function goToContents() {
  window.location.href = 'contents.html';  
}
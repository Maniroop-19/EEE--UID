
const canvas = document.getElementById('bgCanvas');
const ctx = canvas.getContext('2d');


function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);


const PARTICLE_COUNT = 150;  
const particles = [];
let pulseSpeed = 0.18; 


for (let i = 0; i < PARTICLE_COUNT; i++) {
    const colorChoice = Math.random() > 0.5 ? 'rgba(0,255,255,' : 'rgba(255,0,255,'; 
    particles.push({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        radius: Math.random() * 1.2 + 0.6,  
        dx: (Math.random() - 0.5) * 0.8,  
        dy: (Math.random() - 0.5) * 0.8,
        color: colorChoice + (Math.random() * 0.4 + 0.4) + ')',
        speed: Math.random() * 0.4 + 0.3 
    });
}


function syncWithBeat() {
    pulseSpeed = Math.sin(Date.now() * 0.003) * 0.3 + 0.7; 
}


function drawParticles() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);  

    syncWithBeat(); 

    
    particles.forEach(p => {
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2); 
        ctx.fillStyle = p.color;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = 5; 
        ctx.fill();

        
        p.x += p.dx * p.speed * pulseSpeed;
        p.y += p.dy * p.speed * pulseSpeed;

        
        if (p.x < 0) p.x = canvas.width;
        if (p.y < 0) p.y = canvas.height;
        if (p.x > canvas.width) p.x = 0;
        if (p.y > canvas.height) p.y = 0;
    });

    
    requestAnimationFrame(drawParticles);
}
function goBack() {
    window.history.back();
  }
  
drawParticles();  

 
